
export enum TaskCategory {
  AD = 'Watch Ads',
  SURVEY = 'Surveys',
  APP_TEST = 'App Testing',
  REVIEW = 'Post Reviews',
  SOCIAL = 'Social Media',
}

export enum TaskStatus {
  AVAILABLE = 'Available',
  IN_PROGRESS = 'In Progress',
  PENDING = 'Pending Verification',
  COMPLETED = 'Completed',
  REJECTED = 'Rejected',
}

export interface Task {
  id: string;
  title: string;
  description: string;
  reward: number;
  category: TaskCategory;
  timeEstimate: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  status: TaskStatus;
  instructionSteps: string[];
}

export interface User {
  id: string;
  username: string;
  email: string;
  balance: number;
  totalEarned: number;
  referralCode: string;
  level: number;
  completedTasks: number;
}

export interface Transaction {
  id: string;
  type: 'Earning' | 'Withdrawal' | 'Referral';
  amount: number;
  date: string;
  status: 'Completed' | 'Pending' | 'Failed';
  description: string;
}
