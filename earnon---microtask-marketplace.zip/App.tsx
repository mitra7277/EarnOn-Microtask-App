
import React, { useState } from 'react';
import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  ClipboardList, 
  Wallet, 
  User as UserIcon, 
  BookOpen, 
  Bell,
  Menu,
  X
} from 'lucide-react';

import Home from './pages/Home';
import TaskWall from './pages/TaskWall';
import TaskDetail from './pages/TaskDetail';
import WalletPage from './pages/Wallet';
import Profile from './pages/Profile';
import Blueprint from './pages/Blueprint';
import { MOCK_USER } from './constants';

const App: React.FC = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => setSidebarOpen(!isSidebarOpen);

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 text-slate-900 overflow-x-hidden">
        
        {/* Mobile Header */}
        <header className="md:hidden sticky top-0 z-50 bg-white border-b px-4 py-3 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-1.5 rounded-lg">
              <ClipboardList className="text-white w-5 h-5" />
            </div>
            <span className="font-bold text-xl tracking-tight text-indigo-900">EarnOn</span>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative p-2 text-slate-500 hover:text-indigo-600">
              <Bell className="w-6 h-6" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <button 
              onClick={toggleSidebar}
              className="p-2 text-slate-500 hover:text-indigo-600 transition-colors"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </header>

        {/* Sidebar / Desktop Nav */}
        <aside className={`
          fixed inset-y-0 left-0 z-[60] w-64 bg-white border-r transform transition-transform duration-300 ease-in-out
          md:relative md:translate-x-0
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <div className="flex flex-col h-full">
            <div className="p-6 hidden md:flex items-center gap-3 border-b mb-4">
              <div className="bg-indigo-600 p-2 rounded-xl">
                <ClipboardList className="text-white w-6 h-6" />
              </div>
              <span className="font-bold text-2xl tracking-tight text-indigo-900">EarnOn</span>
            </div>

            <nav className="flex-1 px-4 space-y-1 py-4">
              <SidebarLink to="/" icon={<LayoutDashboard size={20} />} label="Dashboard" onClick={() => setSidebarOpen(false)} />
              <SidebarLink to="/tasks" icon={<ClipboardList size={20} />} label="Task Wall" onClick={() => setSidebarOpen(false)} />
              <SidebarLink to="/wallet" icon={<Wallet size={20} />} label="Wallet & Payouts" onClick={() => setSidebarOpen(false)} />
              <SidebarLink to="/profile" icon={<UserIcon size={20} />} label="Profile" onClick={() => setSidebarOpen(false)} />
              <div className="pt-4 mt-4 border-t border-slate-100">
                 <SidebarLink to="/blueprint" icon={<BookOpen size={20} />} label="App Blueprint" onClick={() => setSidebarOpen(false)} />
              </div>
            </nav>

            {/* Profile Summary in Sidebar */}
            <div className="p-4 border-t">
              <div className="bg-slate-50 rounded-xl p-3 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
                  {MOCK_USER.username.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{MOCK_USER.username}</p>
                  <p className="text-xs text-slate-500">Lvl {MOCK_USER.level} Member</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Close button for mobile sidebar */}
          <button 
            onClick={toggleSidebar}
            className="md:hidden absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600"
          >
            <X className="w-6 h-6" />
          </button>
        </aside>

        {/* Backdrop for mobile sidebar */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 md:hidden"
            onClick={toggleSidebar}
          />
        )}

        {/* Main Content Area */}
        <main className="flex-1 h-screen overflow-y-auto relative pb-20 md:pb-6">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/tasks" element={<TaskWall />} />
            <Route path="/tasks/:id" element={<TaskDetail />} />
            <Route path="/wallet" element={<WalletPage />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/blueprint" element={<Blueprint />} />
          </Routes>

          {/* Bottom Mobile Navigation (Alternative to Sidebar on small screens) */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t px-6 py-3 flex justify-between items-center z-50 safe-bottom shadow-lg">
            <BottomLink to="/" icon={<LayoutDashboard size={20} />} label="Home" />
            <BottomLink to="/tasks" icon={<ClipboardList size={20} />} label="Tasks" />
            <BottomLink to="/wallet" icon={<Wallet size={20} />} label="Wallet" />
            <BottomLink to="/profile" icon={<UserIcon size={20} />} label="Me" />
          </div>
        </main>
      </div>
    </HashRouter>
  );
};

const SidebarLink: React.FC<{ to: string, icon: React.ReactNode, label: string, onClick: () => void }> = ({ to, icon, label, onClick }) => {
  const location = useLocation();
  const isActive = location.pathname === to || (to !== '/' && location.pathname.startsWith(to));

  return (
    <Link 
      to={to} 
      onClick={onClick}
      className={`
        flex items-center gap-3 px-4 py-3 rounded-xl transition-all
        ${isActive 
          ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
          : 'text-slate-600 hover:bg-slate-100'
        }
      `}
    >
      {icon}
      <span className="font-medium">{label}</span>
    </Link>
  );
};

const BottomLink: React.FC<{ to: string, icon: React.ReactNode, label: string }> = ({ to, icon, label }) => {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link 
      to={to} 
      className={`flex flex-col items-center gap-1 transition-colors ${isActive ? 'text-indigo-600' : 'text-slate-400'}`}
    >
      {icon}
      <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
    </Link>
  );
};

export default App;
