
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowUpRight, 
  Target, 
  TrendingUp, 
  Clock, 
  Zap, 
  ChevronRight,
  PlusCircle
} from 'lucide-react';
import { MOCK_USER, MOCK_TASKS } from '../constants';

const Home: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-5xl mx-auto">
      {/* Welcome & Balance Section */}
      <section className="bg-indigo-600 rounded-3xl p-6 md:p-8 text-white relative overflow-hidden shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Hello, {MOCK_USER.username}!</h1>
            <p className="text-indigo-100 opacity-90">Ready to earn some extra cash today?</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 w-full md:w-auto">
            <p className="text-sm font-medium text-indigo-100 uppercase tracking-wider mb-1">Available Balance</p>
            <div className="flex items-end gap-2">
              <span className="text-4xl font-black">${MOCK_USER.balance.toFixed(2)}</span>
              <button 
                onClick={() => navigate('/wallet')}
                className="mb-1 text-xs bg-white text-indigo-600 px-3 py-1.5 rounded-full font-bold flex items-center gap-1 hover:bg-indigo-50 transition-colors"
              >
                Withdraw <ArrowUpRight size={14} />
              </button>
            </div>
          </div>
        </div>
        
        {/* Background Decor */}
        <div className="absolute top-[-20%] right-[-10%] w-64 h-64 bg-indigo-500 rounded-full blur-3xl opacity-30"></div>
        <div className="absolute bottom-[-20%] left-[-5%] w-48 h-48 bg-indigo-400 rounded-full blur-3xl opacity-20"></div>
      </section>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={<Target className="text-orange-500" />} label="Tasks Done" value={MOCK_USER.completedTasks.toString()} />
        <StatCard icon={<TrendingUp className="text-emerald-500" />} label="Total Earned" value={`$${MOCK_USER.totalEarned}`} />
        <StatCard icon={<Zap className="text-yellow-500" />} label="User Level" value={MOCK_USER.level.toString()} />
        <StatCard icon={<Clock className="text-blue-500" />} label="Hours Active" value="128h" />
      </div>

      {/* Recommended Tasks */}
      <section>
        <div className="flex items-center justify-between mb-4 px-1">
          <h2 className="text-xl font-bold text-slate-800">Hot Tasks</h2>
          <button 
            onClick={() => navigate('/tasks')}
            className="text-indigo-600 font-semibold text-sm flex items-center gap-1 hover:underline"
          >
            See All <ChevronRight size={16} />
          </button>
        </div>
        
        <div className="space-y-4">
          {MOCK_TASKS.slice(0, 3).map((task) => (
            <div 
              key={task.id}
              onClick={() => navigate(`/tasks/${task.id}`)}
              className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-indigo-300 transition-all cursor-pointer flex items-center gap-4 group shadow-sm hover:shadow-md"
            >
              <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-indigo-600 group-hover:bg-indigo-50 transition-colors">
                <PlusCircle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">{task.title}</h3>
                  <span className="text-emerald-600 font-bold text-lg">${task.reward.toFixed(2)}</span>
                </div>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-xs font-medium text-slate-400">{task.category}</span>
                  <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                  <span className="text-xs font-medium text-slate-400">{task.timeEstimate}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Refer & Earn Banner */}
      <section className="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 flex flex-col md:flex-row items-center gap-6">
        <div className="flex-1 text-center md:text-left">
          <h2 className="text-lg font-bold text-emerald-900 mb-1">Invite Friends & Get $1.00</h2>
          <p className="text-sm text-emerald-700">Earn bonus rewards for every friend who completes their first 3 tasks.</p>
        </div>
        <div className="bg-white border-2 border-dashed border-emerald-200 rounded-xl px-4 py-3 flex items-center gap-3 w-full md:w-auto">
          <span className="text-slate-400 text-xs uppercase font-bold tracking-widest">Code:</span>
          <span className="text-emerald-700 font-black text-lg">{MOCK_USER.referralCode}</span>
          <button className="text-emerald-600 p-1 hover:bg-emerald-50 rounded">
             <ArrowUpRight size={18} />
          </button>
        </div>
      </section>
    </div>
  );
};

const StatCard: React.FC<{ icon: React.ReactNode, label: string, value: string }> = ({ icon, label, value }) => (
  <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
    <div className="mb-2">{icon}</div>
    <p className="text-2xl font-black text-slate-800">{value}</p>
    <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{label}</p>
  </div>
);

export default Home;
