
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  Flame, 
  Smartphone, 
  Play, 
  MessageSquare, 
  Hash,
  Star,
  Clock // Added missing Clock icon import
} from 'lucide-react';
import { MOCK_TASKS } from '../constants';
import { TaskCategory } from '../types';

const TaskWall: React.FC = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState<TaskCategory | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTasks = MOCK_TASKS.filter(task => {
    const matchesCategory = selectedCategory === 'All' || task.category === selectedCategory;
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold text-slate-800">Task Wall</h1>
        <p className="text-slate-500">Find microtasks that match your skills and schedule.</p>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input 
            type="text" 
            placeholder="Search tasks..." 
            className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <button className="flex items-center justify-center gap-2 px-6 py-3 bg-white border border-slate-200 rounded-2xl text-slate-600 font-semibold hover:bg-slate-50 transition-colors">
          <Filter size={18} />
          Filters
        </button>
      </div>

      {/* Category Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
        {['All', ...Object.values(TaskCategory)].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat as any)}
            className={`
              whitespace-nowrap px-5 py-2 rounded-full text-sm font-bold transition-all
              ${selectedCategory === cat 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'bg-white text-slate-500 border border-slate-200 hover:border-indigo-300'
              }
            `}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Task List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTasks.length > 0 ? (filteredTasks.map((task) => (
          <div 
            key={task.id}
            onClick={() => navigate(`/tasks/${task.id}`)}
            className="bg-white rounded-3xl border border-slate-200 overflow-hidden group hover:shadow-xl hover:border-indigo-200 transition-all cursor-pointer flex flex-col"
          >
            <div className="p-5 flex-1 space-y-4">
              <div className="flex items-start justify-between">
                <div className={`p-2.5 rounded-2xl ${getCategoryColor(task.category)}`}>
                  {getCategoryIcon(task.category)}
                </div>
                <div className="flex flex-col items-end">
                   <span className="text-emerald-600 font-black text-xl">${task.reward.toFixed(2)}</span>
                   <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Instant Pay</span>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-slate-800 text-lg group-hover:text-indigo-600 transition-colors leading-tight mb-2">
                  {task.title}
                </h3>
                <p className="text-sm text-slate-500 line-clamp-2 leading-relaxed">
                  {task.description}
                </p>
              </div>

              <div className="flex items-center gap-4 pt-2 border-t border-slate-50">
                <div className="flex items-center gap-1.5 text-slate-400">
                   <Clock size={14} />
                   <span className="text-xs font-bold">{task.timeEstimate}</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-400">
                   <Star size={14} />
                   <span className="text-xs font-bold">{task.difficulty}</span>
                </div>
              </div>
            </div>
            
            <div className="px-5 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{task.category}</span>
              <button className="text-indigo-600 font-bold text-sm flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                Start Task <ChevronRight size={16} />
              </button>
            </div>
          </div>
        ))) : (
          <div className="col-span-full py-20 text-center space-y-4">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-300">
               <Search size={40} />
            </div>
            <div>
              <p className="text-lg font-bold text-slate-800">No tasks found</p>
              <p className="text-slate-500">Try adjusting your filters or search keywords.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const getCategoryIcon = (cat: TaskCategory) => {
  switch (cat) {
    case TaskCategory.AD: return <Play size={22} />;
    case TaskCategory.APP_TEST: return <Smartphone size={22} />;
    case TaskCategory.SURVEY: return <MessageSquare size={22} />;
    case TaskCategory.SOCIAL: return <Hash size={22} />;
    case TaskCategory.REVIEW: return <Star size={22} />;
    default: return <Flame size={22} />;
  }
};

const getCategoryColor = (cat: TaskCategory) => {
  switch (cat) {
    case TaskCategory.AD: return 'bg-red-50 text-red-600';
    case TaskCategory.APP_TEST: return 'bg-blue-50 text-blue-600';
    case TaskCategory.SURVEY: return 'bg-emerald-50 text-emerald-600';
    case TaskCategory.SOCIAL: return 'bg-indigo-50 text-indigo-600';
    case TaskCategory.REVIEW: return 'bg-orange-50 text-orange-600';
    default: return 'bg-slate-50 text-slate-600';
  }
};

const ChevronRight: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
);

export default TaskWall;
