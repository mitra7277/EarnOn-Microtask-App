
import React from 'react';
import { 
  User, 
  Settings, 
  Shield, 
  HelpCircle, 
  LogOut, 
  Share2, 
  Trophy, 
  Mail,
  Edit2
} from 'lucide-react';
import { MOCK_USER } from '../constants';

const Profile: React.FC = () => {
  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-8">
      {/* Profile Header */}
      <section className="bg-white rounded-[40px] border border-slate-200 p-8 shadow-sm flex flex-col md:flex-row items-center gap-8 relative overflow-hidden">
        <div className="relative">
          <div className="w-32 h-32 rounded-[40px] bg-indigo-600 flex items-center justify-center text-white text-4xl font-black shadow-xl shadow-indigo-100 ring-8 ring-slate-50">
            {MOCK_USER.username.charAt(0)}
          </div>
          <button className="absolute bottom-0 right-0 p-2 bg-white border border-slate-200 rounded-2xl text-indigo-600 shadow-md hover:scale-110 transition-transform">
             <Edit2 size={16} />
          </button>
        </div>

        <div className="flex-1 text-center md:text-left space-y-2">
           <div className="flex items-center justify-center md:justify-start gap-3">
             <h1 className="text-3xl font-black text-slate-800">{MOCK_USER.username}</h1>
             <span className="px-3 py-1 bg-amber-100 text-amber-700 text-[10px] font-black uppercase tracking-widest rounded-full">Pro Member</span>
           </div>
           <p className="text-slate-500 flex items-center justify-center md:justify-start gap-2">
             <Mail size={16} />
             {MOCK_USER.email}
           </p>
           <div className="pt-2 flex flex-wrap justify-center md:justify-start gap-4">
              <div className="text-center md:text-left">
                <p className="text-2xl font-black text-slate-800">{MOCK_USER.completedTasks}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tasks Completed</p>
              </div>
              <div className="w-px h-10 bg-slate-100 hidden md:block"></div>
              <div className="text-center md:text-left">
                <p className="text-2xl font-black text-slate-800">{MOCK_USER.level}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Experience Level</p>
              </div>
           </div>
        </div>

        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full blur-3xl opacity-50 -z-10"></div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Referral Box */}
        <section className="bg-indigo-600 rounded-[32px] p-6 text-white space-y-4 shadow-xl shadow-indigo-100">
           <div className="flex items-center gap-3">
             <Share2 size={24} className="text-indigo-200" />
             <h2 className="text-xl font-bold">Refer & Earn</h2>
           </div>
           <p className="text-sm text-indigo-100 leading-relaxed">
             Get $1.00 for every friend who joins using your link and completes their first set of tasks.
           </p>
           <div className="bg-white/10 p-4 rounded-2xl flex items-center justify-between backdrop-blur-md border border-white/20">
             <span className="font-black text-xl tracking-wider uppercase">{MOCK_USER.referralCode}</span>
             <button className="bg-white text-indigo-600 px-4 py-2 rounded-xl text-sm font-bold shadow-sm hover:bg-indigo-50 transition-colors">
               Copy Link
             </button>
           </div>
        </section>

        {/* Level Progress */}
        <section className="bg-white rounded-[32px] border border-slate-200 p-6 space-y-4 shadow-sm">
           <div className="flex items-center justify-between">
             <div className="flex items-center gap-3">
               <Trophy size={24} className="text-amber-500" />
               <h2 className="text-xl font-bold text-slate-800">Next Level</h2>
             </div>
             <span className="text-sm font-bold text-indigo-600">80%</span>
           </div>
           <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
             <div className="h-full bg-indigo-600 rounded-full w-[80%] shadow-lg shadow-indigo-200"></div>
           </div>
           <p className="text-xs text-slate-400 text-center font-medium">Complete 18 more tasks to reach Level 5</p>
        </section>
      </div>

      {/* Settings List */}
      <section className="bg-white rounded-[32px] border border-slate-200 divide-y overflow-hidden shadow-sm">
        <MenuLink icon={<Settings size={20} />} title="Account Settings" subtitle="Privacy, Security, Preferences" />
        <MenuLink icon={<Shield size={20} />} title="Verification" subtitle="Verify your identity for higher limits" />
        <MenuLink icon={<HelpCircle size={20} />} title="Help Center" subtitle="FAQs, Support tickets, Tutorials" />
        <button className="w-full flex items-center gap-4 p-6 hover:bg-red-50 transition-colors text-left group">
           <div className="p-3 bg-red-100 text-red-600 rounded-2xl group-hover:scale-110 transition-transform">
             <LogOut size={20} />
           </div>
           <div>
             <h4 className="font-bold text-red-600">Log Out</h4>
             <p className="text-xs text-red-400">Sign out of your account</p>
           </div>
        </button>
      </section>
    </div>
  );
};

const MenuLink: React.FC<{ icon: React.ReactNode, title: string, subtitle: string }> = ({ icon, title, subtitle }) => (
  <button className="w-full flex items-center justify-between p-6 hover:bg-slate-50 transition-colors text-left group">
     <div className="flex items-center gap-4">
        <div className="p-3 bg-slate-50 text-slate-500 rounded-2xl group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
          {icon}
        </div>
        <div>
          <h4 className="font-bold text-slate-800">{title}</h4>
          <p className="text-xs text-slate-400">{subtitle}</p>
        </div>
     </div>
     <ChevronRight size={20} className="text-slate-300 group-hover:text-indigo-400 group-hover:translate-x-1 transition-all" />
  </button>
);

const ChevronRight: React.FC<{ size: number, className?: string }> = ({ size, className }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="m9 18 6-6-6-6"/></svg>
);

export default Profile;
