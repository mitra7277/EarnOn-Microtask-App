
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  ShieldCheck, 
  AlertCircle, 
  ChevronRight,
  Send,
  Loader2,
  CheckCircle2
} from 'lucide-react';
import { MOCK_TASKS } from '../constants';
import { TaskStatus } from '../types';
import { GoogleGenAI } from "@google/genai";

const TaskDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const task = MOCK_TASKS.find(t => t.id === id);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [proof, setProof] = useState('');
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);

  if (!task) {
    return (
      <div className="p-8 text-center">
        <h2 className="text-xl font-bold">Task not found</h2>
        <button onClick={() => navigate('/tasks')} className="mt-4 text-indigo-600">Back to Task Wall</button>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!proof.trim()) return;

    setIsSubmitting(true);
    
    try {
      // Simulate AI Verification using Gemini
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `I am a user submitting proof for a microtask: "${task.title}". 
        The instructions were: ${task.instructionSteps.join(', ')}.
        My submitted proof text is: "${proof}".
        Please act as an automated task validator. 
        Determine if this proof sounds legitimate or if it's too short/generic.
        Provide a short 2-sentence response explaining if you accept it or if I need more detail. 
        If you accept, start with "APPROVED:". If not, start with "REJECTED:".`
      });

      setAiAnalysis(response.text);
      
      if (response.text?.includes('APPROVED')) {
        setTimeout(() => {
          setIsSubmitting(false);
          setIsCompleted(true);
        }, 1500);
      } else {
        setIsSubmitting(false);
      }
    } catch (error) {
      console.error("AI Error:", error);
      // Fallback behavior if API fails or key is missing
      setTimeout(() => {
        setIsSubmitting(false);
        setIsCompleted(true);
      }, 2000);
    }
  };

  if (isCompleted) {
    return (
      <div className="p-6 md:p-12 max-w-2xl mx-auto text-center space-y-6">
        <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto animate-bounce">
          <CheckCircle2 size={48} />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-black text-slate-800">Task Submitted!</h2>
          <p className="text-slate-500">Your proof is being verified by our AI system. Rewards will be credited to your wallet within 10-30 minutes.</p>
        </div>
        {aiAnalysis && (
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-sm text-slate-600 italic">
            " {aiAnalysis} "
          </div>
        )}
        <div className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <button 
            onClick={() => navigate('/tasks')}
            className="w-full py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg shadow-indigo-200"
          >
            Find More Tasks
          </button>
          <button 
            onClick={() => navigate('/')}
            className="w-full py-4 bg-white border border-slate-200 text-slate-600 font-bold rounded-2xl"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 max-w-3xl mx-auto space-y-6">
      <button 
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 font-semibold transition-colors"
      >
        <ArrowLeft size={18} />
        Back
      </button>

      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 md:p-8 space-y-8">
          <div className="flex flex-col md:flex-row justify-between items-start gap-4">
            <div>
              <span className="inline-block px-3 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-black uppercase tracking-widest rounded-full mb-3">
                {task.category}
              </span>
              <h1 className="text-2xl md:text-3xl font-black text-slate-800 leading-tight">{task.title}</h1>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-3xl font-black text-emerald-600">${task.reward.toFixed(2)}</span>
              <span className="text-xs font-bold text-slate-400">Estimated: {task.timeEstimate}</span>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <ShieldCheck className="text-indigo-600" size={20} />
              Instructions
            </h3>
            <ul className="space-y-3">
              {task.instructionSteps.map((step, idx) => (
                <li key={idx} className="flex gap-4 group">
                  <span className="flex-shrink-0 w-6 h-6 bg-slate-100 text-slate-400 font-bold text-xs rounded-full flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    {idx + 1}
                  </span>
                  <p className="text-slate-600 text-sm leading-relaxed">{step}</p>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex gap-3">
            <AlertCircle className="text-amber-500 flex-shrink-0" size={20} />
            <p className="text-xs text-amber-800 leading-relaxed font-medium">
              Fake submissions or spam will result in a permanent account ban and forfeiture of all earnings. Please be honest with your work.
            </p>
          </div>

          {/* Submission Form */}
          <form onSubmit={handleSubmit} className="pt-6 border-t space-y-4">
            <h3 className="font-bold text-slate-800">Submit Proof</h3>
            <textarea 
              placeholder="Describe what you did or paste the required link/code here..."
              className="w-full min-h-[120px] p-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm"
              value={proof}
              onChange={(e) => setProof(e.target.value)}
              disabled={isSubmitting}
            />
            {aiAnalysis && aiAnalysis.includes('REJECTED') && (
              <div className="bg-red-50 text-red-700 text-xs p-3 rounded-lg border border-red-100">
                <strong>AI Feedback:</strong> {aiAnalysis}
              </div>
            )}
            <button 
              type="submit"
              disabled={isSubmitting || !proof.trim()}
              className={`
                w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all
                ${isSubmitting || !proof.trim()
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  : 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 active:scale-[0.98]'
                }
              `}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="animate-spin" size={20} />
                  AI Verifying...
                </>
              ) : (
                <>
                  <Send size={20} />
                  Submit Task
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default TaskDetail;
