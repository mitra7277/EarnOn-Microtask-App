
import React from 'react';
import { 
  Rocket, 
  Users, 
  ShieldCheck, 
  Layers, 
  Smartphone, 
  CreditCard,
  Target,
  Zap,
  Globe,
  Lock
} from 'lucide-react';

const Blueprint: React.FC = () => {
  return (
    <div className="p-4 md:p-12 max-w-5xl mx-auto space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-5xl font-black text-slate-900 leading-tight">EarnOn App Blueprint</h1>
        <p className="text-xl text-slate-500 max-w-2xl mx-auto">A professional guide to building and scaling a microtask earning platform.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Concept Section */}
        <Section icon={<Rocket className="text-indigo-600" />} title="App Concept">
          <p className="text-slate-600 leading-relaxed">
            EarnOn is a digital marketplace connecting businesses needing micro-labor with gig workers worldwide. It focuses on high-frequency, low-barrier tasks that can be completed on mobile devices in minutes.
          </p>
          <ul className="mt-4 space-y-2">
            <li className="flex items-center gap-2 text-sm font-semibold text-slate-700">
              <Target size={14} /> Target: Students, unemployed youth, commuters.
            </li>
            <li className="flex items-center gap-2 text-sm font-semibold text-slate-700">
              <Zap size={14} /> Value: Fast payout, low friction, gamified experience.
            </li>
          </ul>
        </Section>

        {/* Monetization Section */}
        <Section icon={<CreditCard className="text-emerald-600" />} title="Monetization Model">
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-2xl">
              <h4 className="font-bold text-slate-800 text-sm">Platform Fee (30-40%)</h4>
              <p className="text-xs text-slate-500 mt-1">Charged to advertisers for every task completed and verified.</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl">
              <h4 className="font-bold text-slate-800 text-sm">Withdrawal Fees</h4>
              <p className="text-xs text-slate-500 mt-1">Small fixed fee or percentage for instant processing to PayPal/Crypto.</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl">
              <h4 className="font-bold text-slate-800 text-sm">Premium Ads</h4>
              <p className="text-xs text-slate-500 mt-1">Featured tasks with higher visibility for businesses requiring speed.</p>
            </div>
          </div>
        </Section>

        {/* Security Section */}
        <Section icon={<ShieldCheck className="text-red-600" />} title="Security & Anti-Fraud">
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="p-2 bg-red-50 rounded-lg h-fit">
                <Globe size={16} className="text-red-600" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">IP & Device Binding</h4>
                <p className="text-xs text-slate-500">Prevent multiple accounts from the same physical device or shared VPN.</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="p-2 bg-red-50 rounded-lg h-fit">
                <Zap size={16} className="text-red-600" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">AI Verification</h4>
                <p className="text-xs text-slate-500">Automated OCR and NLP to verify screenshots and text-based task proofs.</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="p-2 bg-red-50 rounded-lg h-fit">
                <Lock size={16} className="text-red-600" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Escrow Wallet</h4>
                <p className="text-xs text-slate-500">Funds are held until the advertiser verifies the task completion.</p>
              </div>
            </div>
          </div>
        </Section>

        {/* Roadmap Section */}
        <Section icon={<Layers className="text-blue-600" />} title="MVP Roadmap">
          <ol className="relative border-l border-slate-200 ml-3 space-y-6 pt-2">
            <li className="ml-6">
              <span className="absolute flex items-center justify-center w-6 h-6 bg-blue-100 rounded-full -left-3 ring-8 ring-white">
                <CheckCircle2 className="text-blue-600" size={14} />
              </span>
              <h4 className="font-bold text-slate-800 text-sm">Phase 1: Foundations</h4>
              <p className="text-xs text-slate-500">User auth, Task Wall, Basic Wallet, Admin Panel for manual approval.</p>
            </li>
            <li className="ml-6">
              <span className="absolute flex items-center justify-center w-6 h-6 bg-slate-100 rounded-full -left-3 ring-8 ring-white">
                <div className="w-2 h-2 bg-slate-400 rounded-full"></div>
              </span>
              <h4 className="font-bold text-slate-800 text-sm">Phase 2: Automation</h4>
              <p className="text-xs text-slate-500">API integrations with ad networks, AI proof verification, Tiered rewards.</p>
            </li>
            <li className="ml-6">
              <span className="absolute flex items-center justify-center w-6 h-6 bg-slate-100 rounded-full -left-3 ring-8 ring-white">
                <div className="w-2 h-2 bg-slate-400 rounded-full"></div>
              </span>
              <h4 className="font-bold text-slate-800 text-sm">Phase 3: Community</h4>
              <p className="text-xs text-slate-500">Referral contests, Global leaderboards, Community moderation system.</p>
            </li>
          </ol>
        </Section>
      </div>

      {/* Tech Stack */}
      <section className="bg-slate-900 rounded-[40px] p-8 text-white">
        <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
          <Smartphone /> Recommended Tech Stack
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <TechItem label="Mobile App" value="React Native / Flutter" />
          <TechItem label="Backend" value="Node.js (NestJS)" />
          <TechItem label="Database" value="PostgreSQL + Redis" />
          <TechItem label="Cloud/Infra" value="AWS / GCP" />
          <TechItem label="Verification" value="Gemini API / GPT-4o" />
          <TechItem label="Payments" value="Stripe / PayPal API" />
          <TechItem label="Analytics" value="Mixpanel / Firebase" />
          <TechItem label="Monitoring" value="Sentry / Datadog" />
        </div>
      </section>
    </div>
  );
};

const Section: React.FC<{ icon: React.ReactNode, title: string, children: React.ReactNode }> = ({ icon, title, children }) => (
  <div className="bg-white rounded-[32px] border border-slate-200 p-8 shadow-sm space-y-6">
    <div className="flex items-center gap-4">
      <div className="p-3 bg-slate-50 rounded-2xl">{icon}</div>
      <h3 className="text-2xl font-bold text-slate-800">{title}</h3>
    </div>
    <div className="h-px bg-slate-100 w-full"></div>
    {children}
  </div>
);

const TechItem: React.FC<{ label: string, value: string }> = ({ label, value }) => (
  <div className="space-y-1">
    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{label}</p>
    <p className="font-bold text-indigo-300">{value}</p>
  </div>
);

const CheckCircle2: React.FC<{ className?: string, size?: number }> = ({ className, size }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
);

export default Blueprint;
