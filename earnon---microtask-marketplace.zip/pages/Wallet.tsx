
import React, { useState } from 'react';
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  History, 
  CreditCard,
  Building2,
  DollarSign,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { MOCK_USER, MOCK_TRANSACTIONS } from '../constants';

const WalletPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'History' | 'Methods'>('History');

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto space-y-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-slate-800">My Wallet</h1>
        <p className="text-slate-500">Manage your earnings and withdraw to your favorite method.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Balance Card */}
        <div className="md:col-span-2 bg-slate-900 rounded-[32px] p-8 text-white relative overflow-hidden shadow-2xl">
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-400 font-bold text-xs uppercase tracking-[0.2em] mb-2">Available for payout</p>
                <h2 className="text-5xl font-black mb-4">${MOCK_USER.balance.toFixed(2)}</h2>
              </div>
              <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-md">
                <Wallet className="text-white w-8 h-8" />
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4 mt-8">
              <button className="flex-1 bg-indigo-600 hover:bg-indigo-500 transition-colors py-4 px-6 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-900/50">
                <ArrowUpRight size={18} />
                Withdraw Now
              </button>
              <button className="flex-1 bg-white/10 hover:bg-white/20 transition-colors py-4 px-6 rounded-2xl font-bold flex items-center justify-center gap-2 backdrop-blur-md">
                <ArrowDownLeft size={18} />
                Add Funds
              </button>
            </div>
          </div>

          {/* Decor */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 rounded-full blur-[80px]"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-48 h-48 bg-emerald-500/10 rounded-full blur-[60px]"></div>
        </div>

        {/* Lifetime Stats */}
        <div className="bg-white rounded-[32px] border border-slate-200 p-6 space-y-6 shadow-sm">
           <h3 className="font-bold text-slate-800 flex items-center gap-2">
             <DollarSign className="text-indigo-600" size={18} />
             Lifetime Earnings
           </h3>
           <div className="space-y-4">
              <div className="flex justify-between items-center pb-4 border-b">
                <span className="text-slate-400 text-sm">Total Earned</span>
                <span className="font-black text-slate-800 text-xl">${MOCK_USER.totalEarned.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b">
                <span className="text-slate-400 text-sm">Total Withdrawn</span>
                <span className="font-black text-slate-800 text-xl">$132.70</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Pending Approval</span>
                <span className="font-black text-amber-600 text-xl">$4.20</span>
              </div>
           </div>
           <div className="bg-indigo-50 p-4 rounded-2xl text-[10px] text-indigo-700 font-bold uppercase tracking-widest text-center">
             Elite Earner Status Achieved
           </div>
        </div>
      </div>

      {/* Tabs Section */}
      <section className="space-y-4">
        <div className="flex items-center gap-6 border-b">
          <button 
            onClick={() => setActiveTab('History')}
            className={`pb-4 text-sm font-bold transition-all relative ${activeTab === 'History' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Transaction History
            {activeTab === 'History' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full"></div>}
          </button>
          <button 
            onClick={() => setActiveTab('Methods')}
            className={`pb-4 text-sm font-bold transition-all relative ${activeTab === 'Methods' ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Withdraw Methods
            {activeTab === 'Methods' && <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full"></div>}
          </button>
        </div>

        {activeTab === 'History' ? (
          <div className="space-y-3">
            {MOCK_TRANSACTIONS.map((tx) => (
              <div key={tx.id} className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center justify-between group hover:border-indigo-200 transition-all shadow-sm">
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-xl ${tx.type === 'Withdrawal' ? 'bg-red-50 text-red-500' : 'bg-emerald-50 text-emerald-500'}`}>
                    {tx.type === 'Withdrawal' ? <ArrowUpRight size={20} /> : <ArrowDownLeft size={20} />}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800">{tx.description}</h4>
                    <p className="text-xs text-slate-400 flex items-center gap-1">
                      <Clock size={12} />
                      {tx.date}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-black text-lg ${tx.type === 'Withdrawal' ? 'text-slate-800' : 'text-emerald-600'}`}>
                    {tx.type === 'Withdrawal' ? '-' : '+'}${tx.amount.toFixed(2)}
                  </p>
                  <span className={`text-[10px] font-bold uppercase tracking-widest ${tx.status === 'Completed' ? 'text-emerald-500' : 'text-amber-500'}`}>
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <MethodCard icon={<CreditCard className="text-indigo-600" />} title="PayPal" subtitle="Instant payout, 2% fee" />
            <MethodCard icon={<Building2 className="text-slate-600" />} title="Bank Transfer" subtitle="2-3 days, No fee" />
            <MethodCard icon={<DollarSign className="text-emerald-600" />} title="Crypto (USDT)" subtitle="Fast payout, Network fee" />
            <MethodCard icon={<CreditCard className="text-orange-600" />} title="Gift Cards" subtitle="Amazon, Steam, Google Play" />
          </div>
        )}
      </section>
    </div>
  );
};

const MethodCard: React.FC<{ icon: React.ReactNode, title: string, subtitle: string }> = ({ icon, title, subtitle }) => (
  <div className="bg-white p-5 rounded-2xl border border-slate-200 flex items-center justify-between hover:shadow-md hover:border-indigo-200 transition-all cursor-pointer group">
    <div className="flex items-center gap-4">
      <div className="p-3 bg-slate-50 rounded-xl group-hover:bg-indigo-50 transition-colors">
        {icon}
      </div>
      <div>
        <h4 className="font-bold text-slate-800">{title}</h4>
        <p className="text-xs text-slate-500">{subtitle}</p>
      </div>
    </div>
    <ChevronRight className="text-slate-300 group-hover:text-indigo-500 transition-colors" size={20} />
  </div>
);

export default WalletPage;
