
import { Task, TaskCategory, TaskStatus, User, Transaction } from './types';

export const MOCK_USER: User = {
  id: 'user_123',
  username: 'GigMaster99',
  email: 'user@example.com',
  balance: 12.50,
  totalEarned: 145.20,
  referralCode: 'EARNON-778',
  level: 4,
  completedTasks: 82,
};

export const MOCK_TASKS: Task[] = [
  {
    id: 't1',
    title: 'Watch 30s Video Ad',
    description: 'Watch a promotional video for a new mobile game and stay on the page.',
    reward: 0.05,
    category: TaskCategory.AD,
    timeEstimate: '1 min',
    difficulty: 'Easy',
    status: TaskStatus.AVAILABLE,
    instructionSteps: [
      'Click start to open the video player',
      'Watch the full 30-second advertisement',
      'Do not close the tab or switch apps',
      'Return here to claim your reward'
    ]
  },
  {
    id: 't2',
    title: 'Fintech App Survey',
    description: 'Share your thoughts on mobile banking features and security.',
    reward: 1.50,
    category: TaskCategory.SURVEY,
    timeEstimate: '10 mins',
    difficulty: 'Medium',
    status: TaskStatus.AVAILABLE,
    instructionSteps: [
      'Complete all 15 questions honestly',
      'Provide detailed feedback on UI/UX',
      'Screenshot the completion page',
      'Submit the screenshot for verification'
    ]
  },
  {
    id: 't3',
    title: 'Test Fitness App Beta',
    description: 'Download "FitFlow" and test the workout logging feature.',
    reward: 5.00,
    category: TaskCategory.APP_TEST,
    timeEstimate: '20 mins',
    difficulty: 'Hard',
    status: TaskStatus.AVAILABLE,
    instructionSteps: [
      'Install the app from the provided link',
      'Register a new account',
      'Log a 5-minute activity',
      'Find and report one bug or UI improvement'
    ]
  },
  {
    id: 't4',
    title: 'Like & Comment on Twitter',
    description: 'Engage with the official EarnOn announcement tweet.',
    reward: 0.10,
    category: TaskCategory.SOCIAL,
    timeEstimate: '2 mins',
    difficulty: 'Easy',
    status: TaskStatus.AVAILABLE,
    instructionSteps: [
      'Visit the linked tweet',
      'Like the tweet',
      'Retweet with a positive comment',
      'Provide your Twitter handle'
    ]
  },
  {
    id: 't5',
    title: 'Product Review: Blue headphones',
    description: 'Write a genuine review for the Blue-Bass headphones on our partner store.',
    reward: 2.00,
    category: TaskCategory.REVIEW,
    timeEstimate: '5 mins',
    difficulty: 'Medium',
    status: TaskStatus.AVAILABLE,
    instructionSteps: [
      'Go to the product page',
      'Write a review of at least 50 words',
      'Include a photo if possible',
      'Submit your review nickname'
    ]
  }
];

export const MOCK_TRANSACTIONS: Transaction[] = [
  { id: 'tr1', type: 'Earning', amount: 5.00, date: '2023-11-20', status: 'Completed', description: 'App Test: Foodie' },
  { id: 'tr2', type: 'Withdrawal', amount: 20.00, date: '2023-11-18', status: 'Completed', description: 'PayPal Payout' },
  { id: 'tr3', type: 'Referral', amount: 1.00, date: '2023-11-15', status: 'Completed', description: 'Referral: mike_s' },
  { id: 'tr4', type: 'Earning', amount: 0.50, date: '2023-11-14', status: 'Completed', description: 'Quick Survey' },
];
